// Question 2 Start
$(document).ready(function(){
    $("button.button1").click(function(){
        $("p.p1").hide(2000);
    });
});

$(document).ready(function(){
    $("button.button2").click(function(){
        $("p.p2").show(2000);
    });
});

$(document).ready(function(){
    $("button.button3").dblclick(function(){
        $("p.p3").toggle(2000);
    });
});

$(document).ready(function(){
    $("input#inp").focus(function(){
        $("input#inp").css("background-color", "yellow");
    });
    $("input#inp").blur(function(){
        $("input#inp").css("background-color", "green");
    });
});
// Question 2 Finish


// Question 3 Start
let x = "salam";
switch(x){
    case 0:
    x = "s";
    break;
    case 1:
    x = "sa";
    break;
    case 2:
    x = "sal";
    break;
    case 3:
    x = "sala";
    break;
    case 4:
    x = "salam";
    break;
    default:
    x = "Hec biri"
}
document.getElementById("sual3").innerHTML = x;
// Question 3 Finish


// Question 4 Start
function random(){
    let alphabet = [ 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L',
              'M', 'N', 'O', 'P', 'Q', 'R',  'S', 'T', 'U', 'V', 'W', 'X',
              'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l',
              'm', 'n', 'o', 'p', 'q', 'r',  's', 't', 'u', 'v', 'w', 'x',
              'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '!', '@',
              '#', '$', '%', '^', '&', '*',  '(', ')', '-', '_', '=', '+',
              '/', '|' ]
    let take = document.getElementById("inp2");
    let show = document.getElementById("show");
    let random = "";
    for (let i = 0; i < take.value; i++){
       random += alphabet[Math.floor(Math.random() * alphabet.length)]
    }
    show.innerHTML = random;
    }
// Question 4 Finish
